Thank you for purchasing this package!

included with:
245+ unique 8x8 pixelart tiles

2 animated characters with:
idle animation
run animation
jump animation
fall animation

1 animated enemy with:
idle animation
jump animation
fall animation

4 Tilemaps:
Grass tilemap
Dirt tilemap
Dirt Background tilemap
Spikes tilemap


14 Decorations:
5 grass tiles
3 unique rocks
2 unique trees
2 unique bushes
1 wooden sign
1 tree stump


Two scenes:
Demo level
Asset gallery

5 layer parallax background